
public class Cvor {
	Cvor next;
	int val;
	public Cvor(int val_) {
		this.next = null;
		this.val = val_;
	}
}
